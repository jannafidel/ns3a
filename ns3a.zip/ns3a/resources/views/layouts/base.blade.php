<link href="https://maxcdn.bootstrapcdn.com/.../css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/.../js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/c88097f817.js" crossorigin="anonymous"></script>
<script src="{{asset('js/custom.js')}}"></script>
<script type="text/javascript">
    var token = '{{ csrf_token() }}';
</script>